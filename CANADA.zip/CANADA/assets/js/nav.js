// Seleccionamos los elementos necesarios
const hamburger = document.querySelector('.hamburger');
const navLinks = document.querySelector('.nav-links');

// Función para abrir y cerrar el menú con el mismo ícono
hamburger.addEventListener('click', () => {
    // Alternamos las clases activas
    hamburger.classList.toggle('is-active'); // Cambia entre hamburguesa y "X"
    navLinks.classList.toggle('active'); // Muestra/oculta el menú
});
