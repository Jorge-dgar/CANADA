let currentSlide = 0; // El índice de la imagen actual
const slides = document.querySelectorAll('.slider-images img'); // Obtener todas las imágenes
const totalSlides = slides.length; // Número total de imágenes

// Mover el slider en función del paso (hacia la izquierda o hacia la derecha)
function moveSlide(step) {
    currentSlide += step;

    // Si llegamos al primer slide, va al último
    if (currentSlide < 0) {
        currentSlide = totalSlides - 1; // Volver al último
    } else if (currentSlide >= totalSlides) {
        currentSlide = 0; // Volver al primero
    }

    updateSlider(); // Actualizamos la vista del slider
}

// Actualizar la posición del slider para mostrar solo una imagen a la vez
function updateSlider() {
    // Desplazamiento en el eje X, ajustando el valor al índice actual
    const offset = -currentSlide * 100; // Desplazamos un 100% por cada paso
    document.querySelector('.slider-images').style.transform = `translateX(${offset}%)`;
}

// Desplazamiento automático cada 3 segundos
setInterval(() => {
    moveSlide(1); // Mover hacia la derecha (1 paso)
}, 3000); // 3 segundos
